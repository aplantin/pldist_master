library(testthat)
library(pldist)

test_check("pldist")
